library(tidyverse)
raw_filename <- "data/counts-raw.txt.gz"
counts_raw <- read.delim(raw_filename,stringsAsFactors = F)
counts_raw <- as_data_frame(counts_raw)
head(counts_raw)

research <- filter(counts_raw,articleType=="Research Article")

research_2006 <- filter(research,year==2006)
nrow(research_2006)

research_2006_tweet <- filter(research_2006,backtweetsCount>0)

research_2006_fb <- filter(research,
                           year==2006,
                           facebookCommentCount>0)

research_2006_fb_tweet <- filter(research,
                           year==2006,
                           facebookCommentCount>0,
                           backtweetsCount>0)
                           

select(research_2006_fb_tweet,title,wikipediaCites,authorsCount)

colnames(research)

select(research,contains("count"))
select(research,contains("Count"),
       -deliciousCount,
       -authorsCount)


select(research,title,wikipedia=wikipediaCites)


tail(head(select(research,title),6),1)

select(research,title) %>% head(6) %>% tail(1)

slice(research,1:3) %>% slice(2)

research %>% 
  arrange(desc(authorsCount),desc(wosCountThru2011)) %>%
  select(authorsCount,wosCountThru2011) %>%
  slice(1:10)

arrange(research,desc(wosCountThru2011)) %>% 
  select(title,wosCountThru2011) %>% 
  slice(1:3)

arrange(research,desc(authorsCount)) %>% 
  select(authorsCount,title,journal,plosSubjectTags) %>% slice(1:3)

 mutate(research,
                   weeksSincePublished=daysSincePublished/7,
                   yearsSincePublished=weeksSincePublished/52) %>%
  select(contains("Since")) %>% slice(1:5)


summarize(research,
          plos_mean=mean(plosCommentCount,na.rm=T),
          plos_sd=sd(plosCommentCount,na.rm=T))

data.frame(plos_mean=mean(research$plosCommentCount[research$journal=="pone"&research$year==2007]),
           plos_sd=sd(research$plosCommentCount[research$journal=="pone"&research$year==2007]))

filter(research,journal=="pone",year==2007) %>%
  summarise(plos_mean=
              mean(plosCommentCount),
            plos_sd=sd(plosCommentCount))

group_by(research,journal) %>% summarise(plos_mean=mean(plosCommentCount),
                                         plos_sd=sd(plosCommentCount))

group_by(research,journal,year) %>% 
  summarise(plos_mean=mean(plosCommentCount),
            plos_sd=sd(plosCommentCount))

tweets_per_journal <- group_by(research,journal) %>% summarise(total=n(),
                                                               Mean_Tweets=mean(backtweetsCount),
                                                               SD_Tweets=sd(backtweetsCount),
                                                               SEM_Tweets=SD_Tweets/sqrt(total))

metric_count <- select(research,journal,contains("Count"),-authorsCount)

tidy_count <- gather(data = metric_count,key = metric_type,
                     value=count,
                     contains("Count"))


tidy_count_sum <- group_by(tidy_count,journal,metric_type) %>% summarise(mean_metric=mean(count))

write.table(tidy_count_sum,file="data/tidy_count_sum.txt",
            sep = ",",
            col.names = T,
            row.names=F,quote = F)

saveRDS(tidy_count,file="data/tidy_count_sum.RDS")
my_df <- readRDS("data/tidy_count_sum.RDS")



# ggplot2 section
## plotting with aesthetics

p <- ggplot(data = research, mapping = aes(x = pdfDownloadsCount,
                                           y = wosCountThru2011)) 
p <- p + geom_point(aes(color=journal)) + geom_smooth()

## Exercise 1: 

q <- ggplot(
  data= research,
  mapping = aes(x = daysSincePublished,
                                     y = wosCountThru2011))
q <- q + geom_point(aes(color=journal), alpha=0.5) + geom_smooth(color="red")



p <- ggplot(data = research, mapping = aes(x = log10(pdfDownloadsCount),
                                           y = log10(wosCountThru2011))) 
p <- p + geom_point(aes(color=journal)) + geom_smooth()

p <- p + scale_x_continuous(breaks = c(1,3), labels=c(10,1000)) +
  scale_y_continuous(breaks=c(1,3), labels=c(10,1000))

# levels(factor(research$journal))

research <- mutate(research, 
                   immuno = grepl("Immunology", plosSubjectTags), 
                   evobio = grepl("Evolutionary Biology", plosSubjectTags))



p %+% dplyr::select(research, -journal) + facet_grid(evobio~immuno)

tweets_bar <- ggplot(tweets_per_journal, aes(x = journal,
                                             y = Mean_Tweets)) +
  geom_bar(stat="identity") + 
  geom_errorbar(aes(ymin = Mean_Tweets - SEM_Tweets, 
                    ymax = Mean_Tweets + SEM_Tweets), width=0.1) + 
  geom_text(aes(label = total), hjust=0, vjust=0)


tweets_point <- ggplot(tweets_per_journal, aes(x = journal,
                                             y = Mean_Tweets)) +
  geom_point() + 
  geom_errorbar(aes(ymin = Mean_Tweets - SEM_Tweets, 
                    ymax = Mean_Tweets + SEM_Tweets), width=0.1) + 
  geom_text(aes(label = total), hjust=0, vjust=0) + 
  labs(title = "Number of Article Tweets per Journal", 
       x= "PLOS Journal", y = "Mean # of Tweets (+/- SE)")








