# NWK 7/24/2017 
#altmetrics first look-
x <- 2+2
y <- x+1



data_filename <- "data/counts-raw.txt.gz"
counts_raw <- read.delim(file = data_filename,
                         stringsAsFactors =FALSE)


counts_raw[1:10,"pmid"]
counts_raw$daysSincePublished[1:10]
str(counts_raw$daysSincePublished)
is.numeric(counts_raw$daysSincePublished)
is.numeric(counts_raw)
is.numeric(counts_raw$daysSincePublished/7)
str(counts_raw$journal)
is.character(counts_raw$journal)
head(counts_raw$journal)
counts_raw$authorsCount[1:10]
is.na(counts_raw$authorsCount)
anyNA(counts_raw$authorsCount)
median(counts_raw$wosCountThru2010)
sum(counts_raw$wosCountThru2010)


plot(counts_raw[,1:4])

counts_raw$authorsCount[1:10]

counts_raw$authorsCount[1:10]>5
counts_raw[counts_raw$authorsCount>5,1]

dim(counts_raw[counts_raw$journal=="pone",])
dim(counts_raw[counts_raw$journal!="pone",])

dim(counts_raw[counts_raw$journal %in% c("pone","pbio","pgen"),])
head(counts_raw$plosSubjectTags[grepl("Immunology",counts_raw$plosSubjectTags)])

tail(counts_raw$plosSubjectTags[counts_raw$plosSubjectTags=="Immunology"])

x <- counts_raw$authorsCount

if(anyNA(x)){
  print("Be careful, data contains missing values!")
}else{
  print("Looks good, data does NOT contain missing values")
}
y <- counts_raw$title
if(!is.character(y)){
  y<- as.character(y)
}

subj_tags <- counts_raw$plosSubjectTags
evo_bio <- counts_raw[grepl("Evolutionary Biology",subj_tags),]

journal <-evo_bio$journal
dim(evo_bio[journal %in% c("pone","pmed","pbio"),])

for(i in c(1,3,5)){
  j <- i+1
  print(j)
}
x <- numeric()
for(i in 1:length(counts_raw$wosCountThru2011)){
  x <- c(x,counts_raw$wosCountThru2011[i]+1)
}

x <- numeric(length(counts_raw$wosCountThru2011))

for(i in 1:length(counts_raw$wosCountThru2011)){
  x[i] <- counts_raw$wosCountThru2011[i]+1
}

result <- numeric(length(levels(factor(counts_raw$journal))))
levels(factor(counts_raw$journal))

for(i in levels(factor(counts_raw$journal))){
  print(i)
}
result <- numeric(length(levels(factor(counts_raw$journal))))
for( j in levels(factor(counts_raw$journal))){
  print(j)
  result[j] <- mean(counts_raw$wosCountThru2011[counts_raw$journal==j])
}
  


